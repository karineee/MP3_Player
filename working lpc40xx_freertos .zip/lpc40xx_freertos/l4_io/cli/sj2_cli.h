#pragma once

void sj2_cli__init(void);
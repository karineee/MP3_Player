// Driver to Display on OLED

#pragma once

#include <stdint.h>

// display is 128 x 64

// 8 pages, 128 segments
// 1 page is D0, to D7, top to bottom
// 0 to 127 segments, left to right.
